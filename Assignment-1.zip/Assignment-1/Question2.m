Rating = [8.6, 7.8, 6.9, 7.5, 6.7, 7, 7, 6, 7, 6.9, 8.5, 7.9, 6.6, 7.7, 6.5, 6.7, 7.2, 7.3, 6.5, 7.6,];
Budget = [55000000, 90000000, 175000000, 129000000, 79000000, 260000000, 125000000, 48000000, 183000000, 200000000, 35600000, 200000000, 150000000, 191000000, 80000000, 185000000, 150000000, 170000000, 200000000, 160000000,];
Collections = [1071160056, 389099213, 1128274794, 521799505, 472993228, 1656943394, 739760805, 699760773, 1050693953, 1048859152, 2797800564, 1073394593, 431705346, 726063471, 429434163, 491643008, 1420958309, 404852543, 758910100, 1131927996];
Movies = {'Joker', 'Once Upon a Time... in Hollywood', 'Captain Marvel', 'How to Train Your Dragon: The Hidden World', 'It Chapter Two', 'The Lion King', 'Jumanji: The Next Level', 'The Wandering Earth', 'Aladdin', 'Star Wars: Episode IX - The Rise of Skywalker', 'Avengers: Endgame', 'Toy Story 4', 'Pokémon Detective Pikachu', 'Ne Zha', 'The Secret Life of Pets 2', 'Maleficent: Mistress of Evil', 'Frozen II', 'Alita: Battle Angel', 'Fast & Furious Presents: Hobbs & Shaw', 'Spider-Man: Far from Home'};
Points = ((Collections./100000000-Budget./100000000).*Rating);


[Points,pointsindex] = sort(Points,'descend');

Movies=Movies(pointsindex);
Collections = Collections(pointsindex);
Collec = Collections./100000000;
Rating = Rating(pointsindex);
ratingArray = [Rating(1:10)' nan(10, 1)];
collecArray = [nan(10,1) Collec(1:10)'];
disp(ratingArray)
data = [ratingArray ; collecArray]';
legends = {'Ratings', nan,nan, 'Collections'};

% bar(data);
yyaxis left
rating_bar = bar(ratingArray);


yyaxis right
collec_bar = bar(collecArray);

legend('rating', '', '', 'Collection in 100M');
title('Top 10 Moview Ratings and Collections');
xticks([1 2 3 4 5 6 7 8 9 10]);
set(gca, 'XTickLabel', Movies(1:10));
h = gca;
h.XTickLabelRotation= 60;

